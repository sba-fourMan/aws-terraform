import json
import requests
import os

def lambda_handler(event, context):
    # Jenkins 서버 URL 및 인증 정보
    jenkins_url = os.getenv("JENKINS_URL")
    jenkins_user = os.getenv("JENKINS_USER")
    jenkins_token = os.getenv("JENKINS_TOKEN")

    # 요청 헤더 설정
    headers = {
        "Content-Type": "application/json"
    }

    # Jenkins API 요청 보내기
    try:
        response = requests.post(
            jenkins_url,
            headers=headers,
            auth=(jenkins_user, jenkins_token)
        )
        # 응답 상태 확인
        if response.status_code == 201:
            print("Jenkins job triggered successfully.")
        else:
            print(f"Failed to trigger Jenkins job. Status code: {response.status_code}")
            print(response.text)
    except Exception as e:
        print(f"Error triggering Jenkins job: {str(e)}")

    return {
        "statusCode": 200,
        "body": json.dumps("Lambda executed")
    }
